===Deskripsi tugas====
Silahkan disana terdapat image "landing-page-luxury" kalian bisa bikin seperti web tersebut atau kalian mau berkreasi sendiri juga tidak masalah selama poin poin yang saya terapkan ada disana
saya sudah menyertakan asset imagesnya tinggal kalian pakai saja

Untuk layout yang lebih jelas bisa dilihat di https://www.figma.com/file/lFFNsvssd1WhQqzoKeOImc/Hotel-Website-Design-Community?node-id=0%3A1

WAJIB MENAMBAKHKAN!! di footer(dibawh) pada "Design By Ayokunle Oriolowo" di link ke https://www.behance.net/mcsteph


==== WAKTU PENGUMPULAN ======
1 NOVEMBER 2020 PUKUL 18:00
LINK https://forms.gle/AZyA8ovMmX3mTfMA6


terimakasih selamat mengerjakan
